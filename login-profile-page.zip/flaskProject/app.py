from flask import Flask, render_template, request, redirect, session
import psycopg2
import psycopg2.extras


app = Flask(__name__)
app.secret_key = 'xyz3231'

database_session=psycopg2.connect(
   database='Social',
   port = 5432,
   host='localhost',
   user='postgres',
   password= '12345'
)
cursor = database_session.cursor(cursor_factory=psycopg2.extras.DictCursor)



@app.route('/')
def home():
    return render_template('login.html')

@app.route('/index', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    message = ''
    email = request.form.get('email')
    password = request.form.get('password')
    if email:
        cursor.execute('SELECT id, name FROM users where email = %s and password = %s', (email, password))
        result = cursor.fetchone()
        if result:
            session['user'] = dict(result)
            return redirect('/index')
            # return render_template('index.html', user=dict(result))
            pass
        else:
            message = 'Error ! password or Email Not correct'
    return render_template('login.html', msg=message)


@app.route('/register', methods=['GET', 'POST'])
def register():
    message = ''
    username = request.form.get('name')
    email = request.form.get('email')
    password = request.form.get('password')
    if email:
        cursor.execute('SELECT email FROM users where email = %s', (email,))
        if cursor.fetchone():
            message = 'Account already exits!'
        else:
            cursor.execute('INSERT INTO Users(name, email, password) VALUES (%s, %s ,%s)', (username, email, password))
            database_session.commit()
            message = 'You have successfully registered'

    return render_template('register.html', msg=message)


@app.route('/logout')
def logout():
    session['user'] = None
    return redirect('/login')

@app.route('/Edit',  methods=['GET', 'POST'])
def Edit():
    message = ''
    Firstname = request.form.get('fname')
    Lastname = request.form.get('lname')
    email = request.form.get('email')
    address = request.form.get('address')
    password = request.form.get('password')
    phone = request.form.get('phone')

    #     cursor.execute('SELECT id, name FROM users where email = %s and password = %s', (Firstname, Lastname, address, email, password, phone))
    #     result = cursor.fetchone()
    #     if result:
    #         session['user'] = dict(result)
    #         return redirect('/')

    return render_template('Edit.html', msg=message)




if __name__ == '__main__':
    app.run()
