function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;
  
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
  }

  function editInformation() {
    // Replace the existing information with input fields for editing
    document.getElementById('personInfo').innerHTML = `
        <h1>Edit Person Information</h1>
        <form id="editForm">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required><br>

            <button type="button" onclick="saveChanges()">Save Changes</button>
        </form>
    `;
}

function saveChanges() {
    // Retrieve values from input fields
    const newName = document.getElementById('name').value;
    const newAge = document.getElementById('age').value;
    const newEmail = document.getElementById('email').value;
    const newLocation = document.getElementById('location').value;

    // Update the displayed information with the edited values
    document.getElementById('personInfo').innerHTML = `
        <h1>Person Information</h1>
        <p><strong>Name:</strong> ${newName}</p>
        <p><strong>Age:</strong> ${newAge}</p>
        <p><strong>Email:</strong> ${newEmail}</p>
        <p><strong>Location:</strong> ${newLocation}</p>

        <button id="editButton" onclick="editInformation()">Edit</button>
    `;
}