import psycopg2
import psycopg2.extras

database_session=psycopg2.connect(
    database='Social',
    port=5432,
    host='localhost',
    user='postgres',
    password='12345'
)
cursor = database_session.cursor(cursor_factory=psycopg2.extras.DictCursor)




if __name__ == '__main__':
 cursor = database_session.cursor(cursor_factory=psycopg2.extras.DictCursor)






